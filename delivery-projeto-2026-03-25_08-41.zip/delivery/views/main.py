from flask import Blueprint, current_app, render_template

bp_main = Blueprint('main', __name__)

@bp_main.route("/")
@bp_main.route("/index")
def index():
    user = {'username': "Gustavo"}
    current_app.logger.info("O endpoint 'index' foi acessado!")
    return render_template('site/main/index.html', user=user)

@bp_main.route("/carrinho")
def carrinho():
    carrinho = {
        'itens': [
            {'id': 1, 'name': "Pizza Margherita", 'preco': 49.95, 'quantidade': 1},
            {'id': 2, 'name': "Refrigerante 1L", 'preco': 8.52, 'quantidade': 2},
            {'id': 3, 'name': "Borda Recheada", 'preco': 12.35, 'quantidade': 1}
        ]
        # 'itens': []   # Teste vazio
    }

    total = sum(item['preco'] * item['quantidade'] for item in carrinho['itens'])

    return render_template(
        'site/main/carrinho.html',
        titulo="Meus Pedidos",
        carrinho=carrinho,
        total=total
    )

@bp_main.route("/xss-demo")
def xss_demo():
    payload = "<script>alert('XSS - demonstrando o risco do | safe')</script>"
    user = {'username': payload}
    return render_template('site/main/index.html', user=user, demo_mode=True)