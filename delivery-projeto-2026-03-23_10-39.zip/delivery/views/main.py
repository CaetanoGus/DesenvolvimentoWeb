from flask import Blueprint, current_app, render_template

bp_main = Blueprint('main', __name__)

@bp_main.route("/")
@bp_main.route("/index")
def index():
    user = {'username': "Gustavo"}
    print("O endpoint 'index' foi acessado!")
    return render_template('site/main/index.html', user=user)